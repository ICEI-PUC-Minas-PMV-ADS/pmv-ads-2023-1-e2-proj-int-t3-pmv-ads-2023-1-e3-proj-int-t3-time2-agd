﻿using System.ComponentModel.DataAnnotations;
namespace WebAPIAgendAI.Models
{
    public abstract class Funcionario
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Obrigatório Informar o nome!")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Obrigatório Informar o email")]
        [EmailAddress(ErrorMessage = "Entre com um email válido")]
        [DataType(DataType.EmailAddress)]
        public string EmailInstitucional { get; set; }


        public Funcionario()
        {

        }

        public virtual bool Login()
        {
            return true;
        }

        public virtual bool Agendamento()
        {
            return true;
        }

        public virtual bool BuscaDatas()
        {
            return true;
        }


    }
}
