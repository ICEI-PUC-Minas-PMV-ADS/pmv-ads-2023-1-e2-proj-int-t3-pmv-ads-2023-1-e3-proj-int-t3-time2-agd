﻿using System.ComponentModel.DataAnnotations;

namespace WebAPIAgendAI.Models
{
    public class Administrador:Funcionario
    {
        [Required(ErrorMessage = "Obrigatório Informar a materia!")]
        public string Materia { get; set; }

        public Administrador(int id, string nome, string emailInstitucional, string materia)
        {
            Id = id;
            Nome = nome;
            EmailInstitucional = emailInstitucional;
            Materia = materia;
        }

        public Administrador()
        {

        }
    }
}
