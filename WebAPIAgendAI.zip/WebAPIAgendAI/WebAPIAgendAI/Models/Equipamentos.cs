﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIAgendAI.Models
{
    public class Equipamentos
    {
        [Key]
        public int NumeroSerie { get; set; }

        [Required(ErrorMessage = "Obrigatório Informar o modelo!")]
        public string Modelo { get; set; }

        [Required(ErrorMessage = "Obrigatório Informar o email")]
        public bool Status { get; set; }
    }
}
